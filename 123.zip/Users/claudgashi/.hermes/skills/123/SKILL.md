---
name: "123"
description: "Startar loop-ed arbetsflödet med strikt root-cause-gate för EventPulse"
---

# 123 — Loop-ED Arbetsflöde

## Trigger
Kör `123` för att starta loop-ed arbetsflödet.

---

## STEG 0: Active Context Resolution (OBLIGATORISKT — ALLTID Först)

### Steg 0a: CWD och Projekt-rot Detection

**KRITISKT:** Kontrollera cwd INNAN någon fil-läsning.

**Auto-detect algoritm:**
1. Om `CWD` slutar med `NEWSTRUCTURE` eller `NEWSTRUCTURE/` → PROJEKT-ROT = CWD
2. Om `CWD/NEWSTRUCTURE` finns → PROJEKT-ROT = `CWD/NEWSTRUCTURE`
3. Om `CWD/../NEWSTRUCTURE` finns → PROJEKT-ROT = `CWD/../NEWSTRUCTURE`
4. Annars: sök uppåt i tree tills NEWSTRUCTURE hittas
5. Om ingen NEWSTRUCTURE hittas → PROJEKT-ROT = CWD (använd cwd direkt)

**Regler:**
- **ANVÄND ALDRIG hardkodad `NEWSTRUCTURE/` prefix** om cwd redan ÄR projektroten
- **ANVÄND ALDRIG `git rev-parse --show-toplevel`** för path-resolution — det kan peka på fel repo
- Om cwd = projekt-rot, använd relativa paths direkt: `02-Ingestion/current-task.md`
- Om cwd ≠ projekt-rot, prependa rätt subpath: `subpath/02-Ingestion/current-task.md`

### Steg 0b: Auto-find Aktiva Filer

Sök i denna ordning (för varje filtyp). **Prependa ALDRIG `NEWSTRUCTURE/` om cwd redan är projekt-rot.**

```
1. {PROJEKT-ROT}/02-Ingestion/current-task.md       ← FINNS: [JA/NEJ]
2. {PROJEKT-ROT}/01-Sources/current-task.md        ← FINNS: [JA/NEJ]  
3. {PROJEKT-ROT}/03-Queue/current-task.md           ← FINNS: [JA/NEJ]
4. {PROJEKT-ROT}/04-Normalizer/current-task.md     ← FINNS: [JA/NEJ]
5. {PROJEKT-ROT}/current-task.md                     ← FINNS: [JA/NEJ] (sista utväg)
```

```
1. {PROJEKT-ROT}/02-Ingestion/handoff.md            ← FINNS: [JA/NEJ]
2. {PROJEKT-ROT}/01-Sources/handoff.md             ← FINNS: [JA/NEJ]
3. {PROJEKT-ROT}/handoff.md                          ← FINNS: [JA/NEJ]
```

**Rules resolution (strömning 1-3):**
- **strömning 1 — För ingestion-domain:**
  ```
  {PROJEKT-ROT}/AI/ingestion.md      ← FINNS: [JA/NEJ]
  {PROJEKT-ROT}/AI/html-discovery.md ← FINNS: [JA/NEJ]
  {PROJEKT-ROT}/AI/ai-routing.md     ← FINNS: [JA/NEJ]
  ```
- **strömning 2 — För andra domains:**
  ```
  {PROJEKT-ROT}/AI/<domain>.md
  ```
- **strömning 3 — Fallback:**
  ```
  global.md
  ```

### Steg 0c: Resolva Aktiv Domän

1. Försök `{PROJEKT-ROT}/02-Ingestion/current-task.md` → domän = ingestion
2. Om inte finns: försök `{PROJEKT-ROT}/<annan-domain>/current-task.md`
3. Domänen vars `current-task.md` faktiskt pekar på verkligt arbete = **aktiv domän**

### Steg 0d: Output av Resolution

```
═══ CONTEXT RESOLUTION ═══
CWD:                    {faktisk cwd}
DETECTED PROJECT-ROOT:  {resolvad projekt-rot}
AKTIV DOMAIN:           {domain}
AKTIV CURRENT-TASK:     {full path eller "SAKNAS"}
AKTIV HANDOFF:          {full path eller "SAKNAS"}
AKTIV RULES:            {full path eller "saknas"}
HTML-DISCOVERY:         {full path eller "saknas"}
AI-ROUTING:             {full path eller "saknas"}
═════════════════════════
```

**Om fil saknas:** Rapportera exakt `SAKNAS` och STOPPA INTE — fortsätt med nästa möjliga path.

**Viktigt om root vs domain-local:**
- Root-filer (`<project-root>/current-task.md`, `<project-root>/handoff.md`) får ALDRIG användas som primär fallback
- Om domain-local finns → det är den enda aktiva
- Om ingen domain-local finns → använd root som sista utväg

## Sources Reality Check (OBLIGATORISKT — EFTER STATUSANALYS)

**KRITISKT: Tre层次 bevis som INTE får likställas:**

| Evidens | Betydelse | Exakt tolkning |
|---------|------------|----------------|
| `sources/*.jsonl` | Source definitions | 420 definitions, varav ~412 har `preferredPath: "unknown"` pga bulk-import — detta betyder "aldrig individuellt konfigurerad", INTE "aldrig testad" |
| `runtime/sources_status.jsonl` | Runtime status (batch triage) | 420 status-rader — alla källor fick EN status-rad, men de flesta kom från batch-triage som körde C1 enbart, INTE full pipeline (C0→C1→C2→extract) |
| `status: "success"` | Fullständigt testad | Endast dessa är verkligt testade med events |

**Förbjudna slutsatser (orsakar självmotsägelser):**
- "420 status-rader = 420 fullständigt testade" — FEL
- "`preferredPath: unknown` = aldrig körd" — FEL  
- "sources/ har 420 filer = 420 testade" — FEL
- "statusrad finns = har testats klart" — FEL

**Korrekt rapportering:**
```
Jag ser:
- X poster i runtime/sources_status.jsonl
- Y success-post (verkligt testade med events)
- Z fail/post som kom från batch-triage (inte full pipeline)
- M sources med preferredPath: unknown (bulk-import, ej individuellt konfigurerade)
Detta bevisar ännu inte exakt hur många som är fullt testade respektive helt oprövade.
```

**Regler för epistemisk försiktighet:**
1. En statusrad bevisar inte fullständig testning
2. `preferredPath: unknown` i sources/ betyder konfigurationsstatus, inte teststatus
3. Antalet filer i sources/ och antalet status-rader är adminstrativa counts, inte test-resultat
4. Endast `status: success` med `lastEventsFound > 0` bevisar framgång
5. `status: fail`, `manual_review`, `triage_required` betyder "testades men misslyckades" — inte "kördes aldrig"

---

### Steg 0e: Rules Gap Check (OBLIGATORISKT — EFTER RULES LOADING)

Efter att regler laddats, kontrollera vilka regler som faktiskt tillämpas i koden.

**Regler att kontrollera för ingestion-domain:**

| Regel | Nyckel att söka i kod | Förväntad tillämpning |
|-------|----------------------|----------------------|
| Generalization Gate | `IGNORE_PATTERNS` + logik för att stoppa enskilda sajter | Finns `IGNORE_PATTERNS` i C0? Stoppar koden enskilda sajter? |
| HTML Frontier Discovery | `internalLinks` / `linkOrigin` / nav+header+submenu | Samlar C0/C1 interna links med klassificering? |
| Candidate Ranking Signals | `timeTagCount` / `dateCount` / `eventDensity` | Räknar C1 page-level signals? |
| AI-Assisted Routing | AI anropas EFTER candidate narrowing | Anropas AI efter regelbaserad ranking? |
| Render Path Rule | `likelyJsRendered` + fallback-logik | Finns JS-detektion? Är render fallback? |
| Logging Rule | Loggning av candidates/ranking/val | Loggas candidate-val och ranking? |
| Rule of Simplification | Inga onödiga steg | Gör agenten enkelt före komplext? |

**Kontrollmetod:**
```
För varje regel:
  1. Sök i kod: grep -n "NYCKEL_BEGREPP" {PROJEKT-ROT}/02-Ingestion/
  2. Om bevis finns → ✓ tillämpad
  3. Om svagt bevis → ⚠ partiellt tillämpad
  4. Om inget bevis → ✗ endast dokumenterad
```

**Output-format (Rules Gap Check):**
```
═══ RULES GAP CHECK ═══
Rule of Simplification:          ✓ bevisad
HTML Frontier Discovery:          ✗ endast dokumenterad (C0 finns men inga interna links)
Candidate Ranking Signals:        ⚠ partiellt (C1 page-signals finns, link-level saknas)
AI-Assisted Routing:             ✗ endast dokumenterad (AI före ranking)
Render Path Rule:                ✓ bevisad (likelyJsRendered finns)
Logging Rule (html-discovery):   ✗ endast dokumenterad
Generalization Gate:             ⚠ partiellt (IGNORE_PATTERNS finns, stop-loggik saknas)
═════════════════════════════════
```

**Regler för Rules Gap Check:**
- Sök i `{PROJEKT-ROT}/02-Ingestion/` för bevis
- "Bevis" = minst en funktion/typ/variabel som implementerar regeln
- "Partiellt" = bevis finns men ofullständig implementation
- "Endast dokumenterad" = ingen implementation hittad

**Om agenten inte kan avgöra:** Rapportera "⚠ oklart" istället för att gissa.

**Output-format (explicita frågor att besvara):**
```
AKTIV RULES: [sökväg till faktiskt laddad fil]
HTML-DISCOVERY: [sökväg eller "saknas"]
AI-ROUTING: [sökväg eller "saknas"]
```

### Steg 0e2: Epistemisk försiktighet vid Source-analys (OBLIGATORISKT)

**Regler för tolkning av source-data:**

**ALDRI likställ dessa:**
- "har statusrad" ≠ "är fullt testad"
- `preferredPath: unknown` ≠ "har aldrig körts"
- antalet filer i `sources/` ≠ antalet källor som körts

**Tre separata data-nivåer:**

1. **`sources/*.jsonl`** = source-definitions (katalogen innehåller potentiella källor)
2. **`runtime/sources_status.jsonl`** = status-rader (körda ELLER importerade, EJ nödvändigtvis fullt testade)
3. **`success` status** = endast de källor som faktiskt har bevisade events > 0

**Korrekt analys-format:**

När du rapporterar source-status, använd ALLTID detta format:

```
═══ SOURCES-ANALYSIS ═══
Sources-filer (sources/):           X poster
Status-rader (sources_status.jsonl): Y poster  
其中 `success`:                  Z poster
其中 `preferredPath: unknown`:    W poster
════════════════════════════
```

**Vid osäkerhet, SÄG DET UTTRYCKLIGEN:**
- ❌ "420 källor har körts" (för starkt om bevis saknas)
- ✅ "Jag ser 420 status-rader i sources_status.jsonl"
- ❌ "412 har aldrig körts" (för starkt)
- ✅ "Jag ser 412 poster med preferredPath: unknown — detta betyder path ej bestämd, inte nödvändigtvis aldrig körts"
- ❌ "Success-rate är X%" (för starkt utan att veta totalen)
- ✅ "20 källor har success status (events > 0), men totalandel av körda källor är oklar"

**Tolkning av `preferredPath`:**

| Värde | Tolkning |
|--------|----------|
| `unknown` | Path ej bestämd — källan KAN ha körts men misslyckades eller importerades med default |
| `html` | HTML-path vald och bekräftad med events |
| `network` | Network-path vald och bekräftad |
| `api` | API-path vald |
| `render` | Render-path vald (kräver D-renderGate) |

### Steg 0f: Strategic Alignment Check

**Kör detta när:** Användaren ger explicit strategisk omdirigering, eller när current-task.md verkar ha site-specifika mål istället för generella.

**Kontrollfrågor:**
1. Är current-task.md mål generella (3+ sajter) eller site-specifika?
2. Överensstämmer det med användarens direktiv?
3. Finns dokumentkonflikt som blockerar arbete?

**Regel: Fixa dokumentation FÖRE kod-ändring.**
```
Om konflikt: Föreslå → pitch → ändra → commit → fortsätt
```

**Output:**
```
═══ STRATEGIC ALIGNMENT ═══
current-task.md mål: [generella/site-specifika]
Användarens mål: [generella/site-specifika]
Konflikt: [JA/NEJ]
═══════════════════════════════
```

### Steg 0g: Workflow Selection
- Läs `{PROJEKT-ROT}/AI/<domain>-loop.md` om det finns
- Om inte → läs `.claude/commands/loop-ed.md`
- Workflow avgörs av aktiv domain

### Explicita frågor att besvara innan Steg 1:

```
═══ CONTEXT RESOLUTION ═══
CWD:                    {faktisk cwd}
DETECTED PROJECT-ROOT:  {resolvad projekt-rot}
AKTIV DOMAIN:           {domain}
AKTIV CURRENT-TASK:     {full path eller "SAKNAS"}
AKTIV HANDOFF:          {full path eller "SAKNAS"}
AKTIV RULES:            {full path eller "saknas"}
HTML-DISCOVERY:         {full path eller "saknas"}
AI-ROUTING:             {full path eller "saknas"}
═════════════════════════

═══ RULES GAP CHECK ═══
[Enradig status per regel]
═══════════════════════════

═══ SOURCES-ANALYSIS ═══
Sources-filer (sources/):           X poster
Status-rader (sources_status.jsonl): Y poster
其中 `success`:                  Z poster
其中 `preferredPath: unknown`:    W poster
════════════════════════════

═══ STRATEGIC ALIGNMENT ═══
current-task.md mål: [generella/site-specifika]
Användarens mål: [generella/site-specifika]
Konflikt: [JA/NEJ]
Åtgärd: [fortsätt/fixa dokument]
═══════════════════════════════
```

---

## Workflow

### Steg 1: Läs aktiv kontext
1. Läs `{PROJEKT-ROT}/CLAUDE.md`
2. Läs `{PROJEKT-ROT}/README.md`
3. Läs **aktiv workflow** (enligt Steg 0)
4. Läs **aktiv current-task** (enligt Steg 0)
5. Läs **aktiv handoff** (enligt Steg 0)
6. **Om aktiv domain är INGESTION, läs ALLTID:**
   - `{PROJEKT-ROT}/AI/ingestion.md` ← JA/NEJ
   - `{PROJEKT-ROT}/AI/html-discovery.md` ← JA/NEJ
   - `{PROJEKT-ROT}/AI/ai-routing.md` ← JA/NEJ
7. `goals.md` är valfri - läs den bara om den faktiskt finns

### Steg 2: Root-cause-gate (OBLIGATORISK)
Innan du ändrar någon kod måste du svara konkret på:

1. Vilket är det exakta problemet just nu?
2. Är problemet uppströms eller nedströms?
3. Är rätt sida / rätt input redan vald?
4. Finns bevis för att felet verkligen ligger i funktionen du tänker ändra?
5. Om `handoff.md` och `current-task.md` pekar åt olika håll:
   - följ `current-task.md`
   - behandla `handoff.md` som historik, inte aktiv styrning

### Steg 2b: Generalization Gate (OBLIGATORISK — SEPARAT STEG)

**INNAN du gör någon ändring i C-lager (C0/C1/C2), svara på dessa:**

1. **Vilken observation kommer från en enda sajt?**
   - Om ja → klassificera som "Site-Specific"
   - Om nej → fortsätt

2. **Finns samma mönster verifierat på minst 2–3 andra domäner?**
   - Om ja → klassificera som "General"
   - Om nej → klassificera som "Provisionally General"

3. **Är problemet egentligen canonicalization, parsing eller site naming?**
   - Canonicalization (www/www-less, trailing slashes) = ofta generellt
   - Parsing (DOM-struktur, selector-logik) = kan vara sitespecifikt
   - Site naming (företagsspecifika termer) = alltid sitespecifikt

4. **Riskerar ändringen att öppna brus på andra sajter?**
   - Att lägga till keywords ökar risken för brus
   - Att ta bort keywords minskar precision

**Klassificering och handling:**

| Klassificering | Handling |
|----------------|----------|
| **General** | Implementation tillåten i C-lager |
| **Provisionally General** | Gör INTE implementation ännu. Sök 2–3 andra domäner. Bekräfta först. |
| **Site-Specific** | STOPPA. Föreslå istället: source adapter, source-specific config, eller manual review |

**Hårda stopp-regler (gäller ALLTID):**
- IGNORE_PATTERNS får INTE ändras baserat på en enda sajt
- scoring-vikter får INTE ändras baserat på en enda sajt
- candidate ranking får INTE ändras baserat på en enda sajt
- URL token logic får INTE ändras baserat på en enda sajt
- negative keyword lists får INTE ändras baserat på en enda sajt

**Exempel:**
- "Folkoperan har `/pa-scen/arkiv/` som блокиras av 'arkiv' i IGNORE_PATTERNS" = Site-Specific → stopp, använd source adapter
- "Flera domäner har `www.example.com` vs `example.com` som olika origins" = General → normalization tillåten

Om svaret visar att rätt sida inte ens väljs ännu:
- ändra INTE extractor
- ändra INTE AI-extraction
- ändra INTE render path
- ändra INTE confidence-tuning nedströms
- fokusera på candidate-page discovery först

### Steg 2c: Pattern Capture (OBLIGATORISK vid Site-Specific)

**Syfte:** När ett Site-Specific-fall avslöjar ett **potentiellt generellt mönster**, spara det strukturerat för framtida verifiering. Utan detta steg försvinner lärdomar in i source adapters och glöms.

**Kör detta steg NÄR:**
- Steg 2b klassificerar som "Site-Specific"
- Men fallet innehåller en observation som KAN vara generell

**Exempel på potentiellt generella mönster:**
- "CMS X använder `w-dyn-list` istället för `<main>/<article>`"
- "extractFromHtml() URL-krav är för smala för Webflow-sajter"
- "Datum-i-text finns men URL har ingen datum-embedding"

**Output-format för Pattern Capture:**

```
### Pattern Capture: [kort namn]

**Klassificering:** Provisionally General (Site: [källa])
**Potentiellt generellt problem:** [vad som observerats]
**URL-struktur som påverkas:** [t.ex. /events/[slug], /kalender/, etc.]
**CMS/Platform om tillämpligt:** [Webflow, SiteVision, etc.]
**Antal sajter verifierade:** 1
**Bevövs verifiering på:** [t.ex. 2-3 andra Webflow-sajter]
**Status:** [t.ex. "Sök verifiering på: sbf, fryshuset"]
```

**Regler:**
1. Spela ALDRIG in ett mönster som redan är känt
2. Spela in KLART och SPECIFIKT — "extractorn missar /events/[slug] URLs" är bra, "url-problem" är för vagt
3. Inkludera alltid CMS/platform om det är relevant (det avgör vilka sajter som ska sökas)
4. Sätt "needsVerification = true" i pattern-records

**När verifiering är BLOCKERAD:**

Om Steg 2b klassificerar som "Provisionally General" och Steg 2c rekommenderar "Sök verifiering på X,Y,Z" MEN inga fler matchande sajter finns:

1. **Markera steget som BLOCKERAD** i handoff.md
2. **Dokumentera anledningen:** "Inga fler [CMS/typ]-sajter i source-listan"
3. **Välj nästa bästa runnable steg** från Render-Queue Blocking Rule (Steg D)
4. **Pattern förblir "Provisionally General"** tills fler sajter hittas

**Sources-status som blockerande faktor:**
Om `sources_status.jsonl` inte matchar verkligheten (t.ex. handoff säger 33 testade, 
men jsonl visar bara 8 core sources), kan nästa tool-verktyg inte köras korrekt.

Lösning: Uppdatera `sources_status.jsonl` med ALLA testade sources först, sedan fortsätt.
Detta är "minsta säkra förändring" som möjliggör nästa steg.

```
### Generalization Gate Status
| Pattern | Sajter verifierade | Krav | Status |
|---------|-------------------|------|--------|
| [Pattern] | N | 2-3 | **BLOCKERAD** — inga fler sajter |
```

**Exempel från verkligheten (loop 9):**
- Pattern: "Webflow CMS Extraction Gap"
- Sajter verifierade: 1 (debaser)
- Krav: 2-3 sajter
- Status: **BLOCKED** — 420 sources testade, inga fler Webflow-sajter finns
- Konsekvens: C-lager-ändring INTE möjlig just nu
- Nästa steg: Uppdatera sources_status.jsonl med 33 testade sources → kör normalizer

**Var sparas mönster:**
- Primärt: `02-Ingestion/PATTERNS.md` (ny fil)
- Sekundärt: handoff.md under egen rubrik

### Steg 3: Utför exakt ett problem
1. Identifiera största verifierbara gapet mot current-task
2. Välj exakt ett problem
3. Gör minsta säkra förändring
4. Verifiera förändringen
5. Uppdatera handoff.md
6. Avgör om samma problem ska fortsätta eller om current-task.md ska ändras
7. Gör git commit

## Autonomous Execution Rule (STRICT)

When `123` is invoked, execute the workflow directly.

**Execution-First Rule:**
- Do NOT ask the user for permission for normal workflow steps
- Do NOT ask "vill du att jag fortsätter?"
- Do NOT ask "ska jag verifiera detta?"

**Normal steps that require NO permission:**
- reading the required markdown files
- identifying the root cause
- inspecting relevant code
- making the smallest safe change
- running lightweight verification
- updating handoff.md
- making a git commit

**Only STOP and ASK when there is a REAL blocker:**
1. missing required file or missing repo context
2. command cannot run due to environment/runtime failure
3. multiple destructive options with materially different outcomes
4. explicit conflict between current-task.md and repository reality that cannot be resolved safely
5. user secrets/credentials are required and unavailable

**If no real blocker exists: continue automatically**

---

## Mandatory Next-Step Analysis (OBLIGATORISKT — EFTER VARJE LOOP)

Efter varje loop OBLIGATORISKT skriva följande analys i handoff.md:

### Mall för nästa-steg-analys

```
## Nästa-steg-analys [TIMESTAMP]

### Vad förbättrades denna loop
- [Faktiskt resultat, inte intention]

### Största kvarvarande flaskhals
- [Root cause, inte symptom]

### Tre möjliga nästa steg

| # | Steg | Systemnytta | Risk | Varför nu |
|---|------|-------------|------|-----------|
| 1 | [namn] | [vad det ger pipeline] | [vad som kan gå fel] | [varför detta är rätt timing] |
| 2 | [namn] | ... | ... | ... |
| 3 | [namn] | ... | ... | ... |

### Rekommenderat nästa steg
- [#] — [kort motivering]

### Två steg att INTE göra nu
1. **[fel steg]** — [varför lockande men fel just nu]
2. **[fel steg]** — [varför lockande men fel just nu]

### System-effect-before-local-effect
- [Förklara varför valt steg ger störst pipeline-nytta, inte bara lokal fil-nytta]
```

### Render-Queue Blocking Rule (OBLIGATORISKT för 02-Ingestion)

**INNAN nästa steg väljs, kör denna kontroll:**

#### Steg A: Identifiera parkerade sources
1. Läs `{PROJEKT-ROT}/runtime/sources_status.jsonl` (eller `{PROJEKT-ROT}/02-Ingestion/sources_status.jsonl`)
2. Sök efter poster med `pendingNextTool: 'D-renderGate'` eller `status: 'pending_render'`
3. Dessa sources är **blockerade** - D-RenderGate finns inte ännu

#### Steg B: Klassificera aktuella candidates

| Evidens | Klassificering | Handling |
|---------|----------------|----------|
| C1 säger `likelyJsRendered=true` | **Verifierad render-kandidat** | Parkera omedelbart |
| C0 density hög MEN extraction=0 AND 403/redirect på event-paths | **Stark misstanke** | Parkera med `confidence: high` |
| Bara hög C0 density, ingen annan evidens | **Vag misstanke** | Tillåt fortsatt analys |
| HTML fungerar (events > 0) | **Ej render-kandidat** | Kan bearbetas nu |

#### Steg C: Beslutsregel

**OM** en källa är verifierad eller starkt misstänkt som render-kandidat:
- ✅ **GÖR:** Parkera i render-kö med tydlig status och reason
- ✅ **GÖR:** Sätt `pendingNextTool: 'D-renderGate'` och `confidence: high/medium/low`
- ✅ **GÖR:** Skriv reason, t.ex. `reason: "C0 density=113, extraction=0, /kalender/=403"`
- ❌ **GÖR INTE:** Rekommendera "undersök [källa]" igen
- ❌ **GÖR INTE:** Välj samma källa som huvud-nästasteg

**OM** render bara är vag misstanke:
- ✅ **TILLÅT:** Fortsatt analys om inget annat kan göras
- ✅ **MARKEA:** `confidence: low` tydligt

#### Steg D: Välj nästa steg från "runnable" sources

Nästa steg ska väljas från sources som:
1. Har bevisad eller möjlig HTML-path (events > 0 eller rimlig density)
2. Är INTE redan parkerade för D-renderGate
3. Kan köras med BEFINTLIGA verktyg (C0/C1/C2, extraction, scheduler)

**Priotiteringsordning:**
1. Sources med `events > 0` som behöver pipeline-verifiering (sourceTriage → phase1ToQueue)
2. Sources med `events = 0` MEN låg density OCH ej verifierad render → undersök
3. Sources med verifierad render → PARK och välj nästa

#### Exempel på fel beslut
```
❌ FEL: "Undersök malmolive" (redan 0 events, C0 density=113, /kalender/=403)
✅ RÄTT: "Kör sourceTriage på malmoopera" (events=8, bevisad path)
✅ RÄTT: "Parkera malmolive för D-renderGate, nästa steg: sourceTriage malmoopera"
```

#### Steg E: Verkställ parkering

Om en source ska parkeras för render, uppdatera `sources_status.jsonl`:

```
# Lägg till eller uppdatera post:
{
  "id": "[källa]",
  "status": "pending_render",
  "pendingNextTool": "D-renderGate",
  "confidence": "high|medium|low",
  "reason": "[specifik anledning]",
  "lastTested": "[ISO timestamp]",
  "evidence": {
    "c0Density": N,
    "extractionEvents": N,
    "httpStatus": N,
    "likelyJsRendered": true|false
  }
}
```

---

## Strong Output Contract (OBLIGATORISKT — EFTER VARJE LOOP)

Efter varje loop, avsluta ALLTID med exakt dessa rubriker. Den sista raden MÅSTE vara `__KLAR_MED_1_2_3_PROMPTEN__` ensam på egen rad, utan punkt och utan text efteråt:

```
## Aktiv kontext
## Rules Gap Check
## Root-cause
## Ändringar
## Verifiering
## Kvarvarande flaskhals
## Tre möjliga nästa steg
## Rekommenderat nästa steg
## Två steg att inte göra nu
## Handoff
## Commit
__KLAR_MED_1_2_3_PROMPTEN__
```

**Kritiskt:** Radera INTE `__KLAR_MED_1_2_3_PROMPTEN__` eller lägg till text efter den. Den ska vara den absolut sista raden i output.

---

## Regler
- Svara alltid på svenska
- Inga broad refactors
- Ett problem åt gången
- Optimera aldrig ett nedströms steg om uppströms val fortfarande är fel
- **Om handoff.md inte uppdaterades är uppgiften inte klar**
- **Om nästa-steg-analys saknas är uppgiften inte klar**
- **Om Strong Output Contract inte följs är uppgiften inte klar**
- **Vid strategisk konflikt: fixa dokumentation FÖRE kod-exekvering**
- **Site-specifika mål i current-task.md → flagga och föreslå generella mål**
- **`__KLAR_MED_1_2_3_PROMPTEN__` ska alltid vara den allra sista raden i output, oavsett exit path (normal completion, timeout, early stop, avbrott, felväg, handoff/partial stop)**

__KLAR_MED_1_2_3_PROMPTEN__
