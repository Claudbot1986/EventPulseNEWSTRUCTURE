## Rule Effectiveness Report batch-72

**Generated:** 2026-04-15T20:03:43.346Z
**Total rules generated:** 5
**Rules applied in next round:** 1
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| medeltidsmuseet | 1 | ENTRY_PAGE_NO_EVENTS | https://medeltidsmuseet.stockholm.se/ | No | N/A |
| sparvag-city | 1 | NEEDS_SUBPAGE_DISCOVERY | /skolor/skolprogram/ | No | N/A |
| uppsala-basket | 1 | LIKELY_JS_RENDER | /game-schedule | No | N/A |
| sundsvall | 1 | EXTRACTION_PATTERN_MISMATCH | /events, /program... | Yes (r2) | no |
| katrineholm | 3 | ENTRY_PAGE_NO_EVENTS | /evenemangskalendern.html | No | N/A |