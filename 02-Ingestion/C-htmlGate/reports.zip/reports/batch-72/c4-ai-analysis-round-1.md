## C4-AI Analysis Round 1 (batch-72)

**Timestamp:** 2026-04-15T20:01:11.607Z
**Sources analyzed:** 8

### Overall Pattern
Top failure categories: 3× DNS resolution failure - domain dead, 1× Cross-domain redirect to subdomain, 1× Low-scoring subpage candidate

---

### Source: medeltidsmuseet

| Field | Value |
|-------|-------|
| likelyCategory | Cross-domain redirect to subdomain |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.85 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | https://medeltidsmuseet.se/ |

**humanLikeDiscoveryReasoning:**
The fetchHtml failed with cross-domain redirect to medeltidsmuseet.stockholm.se. The original domain is redirecting to a subdomain. Need to retry with the new subdomain URL to access event content.

**candidateRuleForC0C3:**
- pathPattern: `Follow redirect chain to final destination domain`
- appliesTo: Sites that redirect to subdomains or alternate domains
- confidence: 0.85

**discoveredPaths:**
- https://medeltidsmuseet.stockholm.se/ [derived] anchor="Cross-domain redirect destination" conf=0.90

**improvementSignals:**
- Cross-domain redirect blocked to medeltidsmuseet.stockholm.se
- Original domain redirects to subdomain - need to follow redirect chain

**suggestedRules:**
- When fetchHtml fails with cross-domain redirect, extract target domain and retry with new domain

---

### Source: regionteatern

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure - domain dead |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failed completely - domain 'regionteater.se' cannot be resolved. No network path exists to reach this site. This is a terminal failure requiring manual verification of the correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS ENOTFOUND - domain may have expired or changed
- No alternate paths available from c0LinksFound

**suggestedRules:**
- Verify domain spelling and check for typosquatting or domain expiration

---

### Source: v-ster-s-konstmuseum

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure - domain dead |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failed completely - domain 'vasterasmuseum.se' cannot be resolved. No network path exists to reach this site. This is a terminal failure requiring manual verification of the correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS ENOTFOUND - domain may have expired or changed
- No alternate paths available from c0LinksFound

**suggestedRules:**
- Verify domain spelling and check for typosquatting or domain expiration

---

### Source: sparvag-city

| Field | Value |
|-------|-------|
| likelyCategory | Low-scoring subpage candidate |
| failCategory | NEEDS_SUBPAGE_DISCOVERY |
| failCategoryConfidence | 0.75 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /skolor/skolprogram/ |

**humanLikeDiscoveryReasoning:**
C0 found 2 candidates with /skolor/skolprogram/ winning. Score of 4 is below threshold. This appears to be a school programs page rather than events page. Need to explore if there are other event-related paths or if this page uses JS rendering.

**candidateRuleForC0C3:**
- pathPattern: `/skolor/*|/program/*`
- appliesTo: Museum and cultural sites with educational programs
- confidence: 0.50

**discoveredPaths:**
- /skolor/skolprogram/ [derived] anchor="derived-rule" conf=0.55

**improvementSignals:**
- C2 score of 4 is below threshold (12)
- Found /skolor/skolprogram/ as winner but unclear if this is event page
- No time tags or date signals detected

**suggestedRules:**
- Subpage candidates with scores 4-8 may need deeper extraction or JS rendering check

---

### Source: uppsala-basket

| Field | Value |
|-------|-------|
| likelyCategory | JS-rendered schedule page |
| failCategory | LIKELY_JS_RENDER |
| failCategoryConfidence | 0.80 |
| nextQueue | D |
| discoveryAttempted | true |
| discoveryPathsTried | /game-schedule |
| directRouting | D (conf=0.82) |

**humanLikeDiscoveryReasoning:**
Found game-schedule URL with multiple UUID query parameters. This pattern is characteristic of client-side rendered sports schedules. The 0 timeTags count confirms static HTML has no event data - content is loaded via JavaScript.

**candidateRuleForC0C3:**
- pathPattern: `/game-schedule|/schedule|/matches`
- appliesTo: Sports team sites with dynamic schedule pages
- confidence: 0.70

**discoveredPaths:**
- /game-schedule [derived] anchor="game-schedule?seasonUuid=ye02q4jwit&seriesUuid=qZo-87H8Vw291&gameTypeUuid=qZn-4XuTzFdn0&completeSeason=all&homeAway=all&allGames=all" conf=0.75

**improvementSignals:**
- Game schedule URL with query parameters suggests dynamic content
- No time tags or date signals in HTML
- c1LikelyJsRendered=false but 0 timeTags indicates client-side rendering

**suggestedRules:**
- URLs with seasonUuid, seriesUuid, gameTypeUuid query params typically use JS rendering
- Route to D (render fallback) for dynamic schedule pages

---

### Source: sundsvall

| Field | Value |
|-------|-------|
| likelyCategory | Promising score but extraction failed |
| failCategory | EXTRACTION_PATTERN_MISMATCH |
| failCategoryConfidence | 0.80 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /kultur, /events, /program, /kalender, /evenemang |

**humanLikeDiscoveryReasoning:**
Multiple event-indicating paths found via derived rules. The /kultur path was selected by C0 but extraction failed despite promising C2 score. Need to try alternate paths like /events or /evenemang which have higher confidence as direct event listings.

**candidateRuleForC0C3:**
- pathPattern: `/events|/evenemang|/kalender|/program`
- appliesTo: Swedish municipal and cultural sites
- confidence: 0.88

**discoveredPaths:**
- /events [nav-link] anchor="derived-rule" conf=0.90
- /program [nav-link] anchor="derived-rule" conf=0.85
- /kalender [nav-link] anchor="derived-rule" conf=0.80
- /evenemang [nav-link] anchor="derived-rule" conf=0.85
- /kultur [nav-link] anchor="derived-rule" conf=0.70

**improvementSignals:**
- C2 score 13 is promising but extraction returned 0 events
- Multiple event-indicating links found (/events, /program, /kalender, /evenemang)
- Winner /kultur may have different HTML structure than expected

**suggestedRules:**
- When promising score but 0 events extracted, HTML structure may not match extraction patterns
- Try alternate extraction patterns or check if content uses different markup

---

### Source: malmo-folkets-park

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure - domain dead |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failed completely - domain 'folketsparkmalmo.se' cannot be resolved. No network path exists to reach this site. This is a terminal failure requiring manual verification of the correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS ENOTFOUND - domain may have expired or changed
- No alternate paths available from c0LinksFound

**suggestedRules:**
- Verify domain spelling and check for typosquatting or domain expiration

---

### Source: vaxjo-alcazar

| Field | Value |
|-------|-------|
| likelyCategory | SSL certificate mismatch |
| failCategory | robots_or_policy_blocked |
| failCategoryConfidence | 0.90 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
SSL certificate mismatch - the host 'alcazar.se' is not in the certificate's altnames which only contains 'yono1.active24.cz'. This indicates either a misconfigured site or the domain is now pointing to a different server. Manual review required to verify correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- Certificate altnames show DNS:yono1.active24.cz
- Host alcazar.se is not in certificate - likely misconfiguration or domain takeover

**suggestedRules:**
- SSL certificate mismatch indicates site misconfiguration or security issue
- Manual verification needed to determine correct domain/SSL configuration

---
