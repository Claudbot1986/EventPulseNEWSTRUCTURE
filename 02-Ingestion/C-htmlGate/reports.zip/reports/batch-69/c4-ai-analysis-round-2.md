## C4-AI Analysis Round 2 (batch-69)

**Timestamp:** 2026-04-15T19:53:05.464Z
**Sources analyzed:** 9

### Overall Pattern
Top failure categories: 9× unclear

---

### Source: teater-galeasen

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: hovet

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: open-air

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: kungstradgarden

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: orebro-vinterfest

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: norrkoping-art

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malmo-massan

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malmo-stad

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: halmstad-stadsteatern

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---
