## C4-AI Analysis Round 2 (batch-81)

**Timestamp:** 2026-04-16T16:16:50.831Z
**Sources analyzed:** 10

### Overall Pattern
Top failure categories: 10× unclear

---

### Source: orebro-festival

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: uppsala-museum

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: historiska-museet

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malmo-ff

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: studieframjandet

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malm-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: linnaeus-museum

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: norrk-pings-tidningar

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malmo-hockey

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: brommapojkarna

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---
