## Rule Effectiveness Report batch-82

**Generated:** 2026-04-16T16:23:17.887Z
**Total rules generated:** 3
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| helsingborgs-dagblad | 2 | ENTRY_PAGE_NO_EVENTS | / | No | N/A |
| slu | 2 | ENTRY_PAGE_NO_EVENTS | / | No | N/A |
| norrkoping-stadsteatern | 2 | ENTRY_PAGE_NO_EVENTS | / | No | N/A |