## C4-AI Analysis Round 2 (batch-82)

**Timestamp:** 2026-04-16T16:21:21.722Z
**Sources analyzed:** 10

### Overall Pattern
Top failure categories: 1× 404 on event path, 1× Redirect chain failure, 1× Extraction missed events

---

### Source: helsingborgs-dagblad

| Field | Value |
|-------|-------|
| likelyCategory | 404 on event path |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.78 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /evenemang |

**humanLikeDiscoveryReasoning:**
Entry page /evenemang returns 404. Swedish newspaper event URLs often change structure. Root domain hd.se should be attempted as it may have current event navigation.

**candidateRuleForC0C3:**
- pathPattern: `/|/kultur|/lokalt`
- appliesTo: Swedish newspaper sites with restructured event URLs
- confidence: 0.62

**discoveredPaths:**
- / [url-pattern] anchor="root domain fallback" conf=0.55

**improvementSignals:**
- 404 on /evenemang path indicates possible URL restructuring
- Root domain hd.se might have working event section
- Swedish newspaper sites often reorganize event listings

**suggestedRules:**
- Try root domain when specific event path returns 404
- Swedish newspapers may use /kultur, /lokalt or main nav for events

---

### Source: vasalund

| Field | Value |
|-------|-------|
| likelyCategory | Redirect chain failure |
| failCategory | ambiguous_multiple_paths |
| failCategoryConfidence | 0.71 |
| nextQueue | manual-review |
| discoveryAttempted | true |
| discoveryPathsTried | / |

**humanLikeDiscoveryReasoning:**
Root redirects exceeded limit. Cannot determine if redirects lead to events or dead domains. Sports clubs often redirect to ticket platforms which may or may not contain accessible event data.

**discoveredPaths:**
(none)

**improvementSignals:**
- Exceeded 3 redirects suggests domain redirect loop or CDN redirect
- Redirect chain may lead to event page on different domain
- Sports club sites often use external ticketing platforms

**suggestedRules:**
- Investigate final redirect destination for event content
- Consider external platform (Ticketmaster, Eventim) redirects as valid paths

---

### Source: smalandsposten

| Field | Value |
|-------|-------|
| likelyCategory | Extraction missed events |
| failCategory | EXTRACTION_PATTERN_MISMATCH |
| failCategoryConfidence | 0.82 |
| nextQueue | D |
| discoveryAttempted | false |
| directRouting | D (conf=0.74) |

**humanLikeDiscoveryReasoning:**
C2 scored page as promising (24) with event-heading class found, but C3 extraction returned 0. Pattern-based extraction likely missing dynamic event containers or uses non-standard date formatting.

**discoveredPaths:**
(none)

**improvementSignals:**
- c2Score=24 indicates page has event-heading elements
- 10 candidate links found but 0 extracted
- c1LikelyJsRendered=false but extraction still failed - pattern mismatch

**suggestedRules:**
- Event pages with CSS class-based extraction need updated selectors
- sport section may use dynamic loading or different HTML structure
- Consider broader date/time extraction patterns

---

### Source: malmo-redhawks

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failed |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS lookup failed completely - domain either does not exist or has expired. No viable navigation paths can be discovered without resolving the DNS issue first.

**discoveredPaths:**
(none)

**improvementSignals:**
- ENOTFOUND on xn--malmredhawks-7ib.se (punycode domain)
- Domain may have expired or moved
- Swedish ö character encoding issue possible

**suggestedRules:**
- Investigate punycode domain validity
- Try malmoredhawks.se without Swedish characters

---

### Source: slakthuset

| Field | Value |
|-------|-------|
| likelyCategory | Root page 404 |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.88 |
| nextQueue | manual-review |
| discoveryAttempted | true |
| discoveryPathsTried | / |

**humanLikeDiscoveryReasoning:**
Root URL returns 404. If the base domain is dead, no event paths can be discovered through navigation. Site may have been replaced by external ticketing platform.

**discoveredPaths:**
(none)

**improvementSignals:**
- Root domain returns 404
- Site may be decommissioned or moved
- Stockholm venue possibly rebranded

**suggestedRules:**
- Confirm if slakthuset.se still operates as event venue
- Search for alternative domain or event platform

---

### Source: malmo-massan

| Field | Value |
|-------|-------|
| likelyCategory | Server unreachable |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.94 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
Connection actively refused by server. Cannot discover event paths without network access. Server may be down or blocking crawler IPs.

**discoveredPaths:**
(none)

**improvementSignals:**
- ECONNREFUSED to 217.70.184.38:443
- Server actively rejecting connections
- IP belongs to Wix/website builder possibly

**suggestedRules:**
- Confirm server status and firewall rules
- Site may require specific user-agent or SSL configuration

---

### Source: goteborgs-design-festival

| Field | Value |
|-------|-------|
| likelyCategory | DNS lookup failed |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failed - domain does not exist or has expired. No navigation paths possible without valid domain resolution.

**discoveredPaths:**
(none)

**improvementSignals:**
- ENOTFOUND on designfestival.se
- Festival may be seasonal/inactive
- Domain may have expired

**suggestedRules:**
- Verify if designfestival.se is still active
- Check if festival moved to gothenburg.se subdomain

---

### Source: lth

| Field | Value |
|-------|-------|
| likelyCategory | Calendar extraction failed |
| failCategory | EXTRACTION_PATTERN_MISMATCH |
| failCategoryConfidence | 0.79 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Kalendarium page detected as promising but extraction failed. University calendars typically use structured server-side rendering that may not match generic event extraction patterns. Try feed/API route.

**discoveredPaths:**
(none)

**improvementSignals:**
- c2Score=26 with event-list page class detected
- 10 candidate links found
- c1DateCount=4 suggests date elements exist
- University calendar likely has API or structured data

**suggestedRules:**
- University event calendars often use /kalender, /schema or feed endpoints
- Consider JSON feed or iCal discovery for academic sources
- Swedish universities (LTH, SLU, etc.) may share calendar CMS

---

### Source: slu

| Field | Value |
|-------|-------|
| likelyCategory | Event path 404 |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.80 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /evenemang |

**humanLikeDiscoveryReasoning:**
/evenemang returns 404 but Swedish universities typically maintain event calendars. Root domain slu.se may contain current kalendarium or event listing.

**candidateRuleForC0C3:**
- pathPattern: `/|/kalendarium|/event|/aktuellt`
- appliesTo: Swedish university and academic institution event pages
- confidence: 0.68

**discoveredPaths:**
- / [url-pattern] anchor="root domain fallback" conf=0.60

**improvementSignals:**
- 404 on /evenemang path
- Swedish university often use /kalendarium, /event or root for events
- Root domain may have working calendar

**suggestedRules:**
- Try root domain when /evenemang returns 404
- Swedish academic sites (LTH, SLU, Uppsala) often use /kalendarium
- Consider institutional subdomain patterns like /sv/event

---

### Source: norrkoping-stadsteatern

| Field | Value |
|-------|-------|
| likelyCategory | Theater section 404 |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.76 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /stadsteatern |

**humanLikeDiscoveryReasoning:**
Stadsteatern subsection returns 404. Municipality theaters often integrate events into main city website or use external ticketing. Root norrkoping.se should be attempted.

**candidateRuleForC0C3:**
- pathPattern: `/|/kultur|/evenemang|/biljetter`
- appliesTo: Swedish municipal theater and cultural event pages
- confidence: 0.62

**discoveredPaths:**
- / [url-pattern] anchor="root domain fallback" conf=0.58

**improvementSignals:**
- 404 on /stadsteatern subpage
- norrkoping.se is municipality site with events elsewhere
- Municipal sites may use /kultur, /evenemang or subsite paths

**suggestedRules:**
- Try root norrkoping.se for theater/events
- Municipality theaters often on subsites or external platforms
- Consider Kulturens Kannibaler or regional ticketing platforms

---
