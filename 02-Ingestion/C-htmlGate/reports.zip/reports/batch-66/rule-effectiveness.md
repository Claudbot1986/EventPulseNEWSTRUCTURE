## Rule Effectiveness Report batch-66

**Generated:** 2026-04-15T19:43:44.864Z
**Total rules generated:** 0
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|