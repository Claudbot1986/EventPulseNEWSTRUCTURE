## C4-AI Analysis Round 1 (batch-66)

**Timestamp:** 2026-04-15T19:40:51.570Z
**Sources analyzed:** 9

### Overall Pattern
Top failure categories: 9× unclear

---

### Source: visit-sweden

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: norrkoping-stadsteatern

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malmo-museum

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: uppsala-linn-science-park

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: linkoping-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: swedish-food

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: liljevalchs

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: malmo-konstmuseum

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: uppsala-stadsteatern-1

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---
