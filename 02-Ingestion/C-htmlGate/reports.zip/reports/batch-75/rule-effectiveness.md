## Rule Effectiveness Report batch-75

**Generated:** 2026-04-15T20:19:03.177Z
**Total rules generated:** 2
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| science-park | 2 | NEEDS_SUBPAGE_DISCOVERY | /events, /program... | No | N/A |
| stenungsund | 3 | ENTRY_PAGE_NO_EVENTS | /events, /program... | No | N/A |