## C4-AI Analysis Round 1 (batch-75)

**Timestamp:** 2026-04-15T20:14:54.760Z
**Sources analyzed:** 8

### Overall Pattern
Top failure categories: 5× DNS resolution failure, 1× Request timeout, 1× Cross-domain redirect blocked

---

### Source: sticky-fingers

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network-level DNS failure prevents any content discovery. No HTML was fetched to analyze.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed for stickyfingers.se - domain may not exist or be misspelled
- Original URL uses stickyfingers.se (no hyphen) but sourceId suggests sticky-fingers (with hyphen)

**suggestedRules:**
- Verify domain spelling: stickyfingers.se vs sticky-fingers.se
- Check if domain has been registered and is active

---

### Source: sundsvall-musik

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network-level DNS failure prevents any content discovery. No HTML was fetched to analyze.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed for musiksundsvall.se - domain may not exist
- Source may have moved to a different domain or platform

**suggestedRules:**
- Verify domain exists via WHOIS lookup
- Search for alternative domain or social media presence

---

### Source: hv71

| Field | Value |
|-------|-------|
| likelyCategory | Request timeout |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.85 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network timeout prevents content discovery. Timeout may be transient - retry warranted.

**discoveredPaths:**
(none)

**improvementSignals:**
- Server timeout after 20000ms - server may be slow or temporarily unavailable
- HV71 is a known Swedish hockey club - site likely exists but was unresponsive

**suggestedRules:**
- Retry with extended timeout
- Verify site is accessible via alternative method

---

### Source: orebro-festival

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network-level DNS failure prevents any content discovery. No HTML was fetched to analyze.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed for orebrofestivalen.se - domain may not exist
- Festival may use different naming (Örebro Festivalen vs Örebrofestivalen)

**suggestedRules:**
- Verify domain spelling and existence
- Search for alternative domain or event platform

---

### Source: trollhattans-if

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network-level DNS failure prevents any content discovery. No HTML was fetched to analyze.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed for trollhattanif.se - domain may not exist
- Club may use different domain or social media presence

**suggestedRules:**
- Verify domain spelling (trollhattan vs trollhättan)
- Search for alternative domain or platform

---

### Source: spanggatan

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network-level DNS failure with IDN domain prevents content discovery. No HTML was fetched to analyze.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed for punycode version of spånggatan.se
- IDN domain may have encoding issues or may not be registered

**suggestedRules:**
- Verify IDN domain registration and proper encoding
- Try alternative spellings or domain formats

---

### Source: vasalund

| Field | Value |
|-------|-------|
| likelyCategory | Cross-domain redirect blocked |
| failCategory | robots_or_policy_blocked |
| failCategoryConfidence | 0.92 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cross-domain redirect blocked by policy. Site redirects to qvmcd.com ticketing platform - events likely exist there but cannot be accessed via direct crawl.

**discoveredPaths:**
(none)

**improvementSignals:**
- Cross-domain redirect blocked: vasalund.se → qvmcd.com
- Site redirects to external platform (qvmcd.com) which may be a ticketing/event platform

**suggestedRules:**
- Investigate qvmcd.com as potential event source
- Check if vasalund.se events are hosted on external platform

---

### Source: science-park

| Field | Value |
|-------|-------|
| likelyCategory | Events on subpages |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.88 |
| nextQueue | retry-pool |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
Entry page (spp.se) has no events but contains multiple high-confidence event-indicating navigation links. Swedish cultural/municipal sites commonly structure events under /events, /program, /kalender, or /schema. These paths should be crawled in retry-pool to find event listings.

**candidateRuleForC0C3:**
- pathPattern: `/events|/program|/kalender|/schema|/evenemang|/kalendarium`
- appliesTo: Swedish cultural, municipal, and institutional sites with event listings
- confidence: 0.85

**discoveredPaths:**
- /events [nav-link] anchor="derived-rule" conf=0.85
- /program [nav-link] anchor="derived-rule" conf=0.82
- /kalender [nav-link] anchor="derived-rule" conf=0.80
- /schema [nav-link] anchor="derived-rule" conf=0.75
- /evenemang [nav-link] anchor="derived-rule" conf=0.78
- /kalendarium [nav-link] anchor="derived-rule" conf=0.72
- /aktiviteter [nav-link] anchor="derived-rule" conf=0.68
- /utställningar [nav-link] anchor="derived-rule" conf=0.65
- /exhibition [nav-link] anchor="derived-rule" conf=0.60
- /exhibitions [nav-link] anchor="derived-rule" conf=0.58

**improvementSignals:**
- Entry page has no events but multiple event-indicating navigation links found
- c2Score=7 indicates weak but present event signals in HTML
- Strong candidate paths: /events, /program, /kalender, /schema

**suggestedRules:**
- Crawl subpages with event-indicating paths
- Prioritize Swedish event paths: /events, /kalender, /program

---
