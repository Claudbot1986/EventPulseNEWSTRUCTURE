## Rule Effectiveness Report batch-60

**Generated:** 2026-04-15T19:02:06.514Z
**Total rules generated:** 1
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| studio-acusticum | 2 | NEEDS_SUBPAGE_DISCOVERY | /evenemang/ | No | N/A |