## C4-AI Analysis Round 1 (batch-71)

**Timestamp:** 2026-04-15T19:58:37.379Z
**Sources analyzed:** 8

### Overall Pattern
Top failure categories: 4× DNS resolution failed - domain does not exist, 1× DNS resolution failed - subdomain does not exist, 1× Cross-domain redirect to unrelated site

---

### Source: karlstad-if

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failed - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - fetchHtml failed at network layer with ENOTFOUND. No HTML content available to analyze. Domain karlstadif.se does not resolve via DNS.

**discoveredPaths:**
(none)

**improvementSignals:**
- Verify domain spelling: karlstadif.se may be incorrect
- Try common Swedish sports club domain patterns: karlstad-if.se, karlstadif.nu

**suggestedRules:**
- For ENOTFOUND errors: check if domain has moved to .nu, .com, or subdomain pattern

---

### Source: svenska-innebandyf-rbundet

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failed - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - fetchHtml failed at network layer with ENOTFOUND. No HTML content available to analyze. Domain svenskaif.se does not resolve via DNS.

**discoveredPaths:**
(none)

**improvementSignals:**
- Verify domain spelling: svenskaif.se may be incorrect
- Try searching for correct Swedish Floorball Federation website

**suggestedRules:**
- For ENOTFOUND errors: domain may have moved or be misspelled

---

### Source: stora-teatern-g-teborg

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failed - subdomain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - fetchHtml failed at network layer with ENOTFOUND. No HTML content available to analyze. Subdomain stora-teatern.goteborg.se does not resolve via DNS.

**discoveredPaths:**
(none)

**improvementSignals:**
- Verify subdomain pattern: stora-teatern.goteborg.se may be incorrect
- Try goteborg.se/stora-teatern or stora-teatern.se

**suggestedRules:**
- For municipal sites: check if subdomain pattern matches main domain structure

---

### Source: vaxjo-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | Cross-domain redirect to unrelated site |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.92 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - cross-domain redirect blocked. URL points to vx.se which redirects to vxfiber.com (unrelated telecom site), not a concert hall. No HTML content available to analyze.

**discoveredPaths:**
(none)

**improvementSignals:**
- URL redirects to vxfiber.com (telecom provider) - not a concert hall
- Correct URL likely: vaxjo.se/konserthus or konserthusvaxjo.se

**suggestedRules:**
- For cross-domain redirects: check if redirect target matches expected content type

---

### Source: vasteras-stadsteatern

| Field | Value |
|-------|-------|
| likelyCategory | Page returns 404 - URL path incorrect |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - HTTP 404 returned. No HTML content available to analyze. The URL path /stadsteatern does not exist on vasteras.se.

**discoveredPaths:**
(none)

**improvementSignals:**
- URL path /stadsteatern returns 404
- Try vasteras.se/kultur/stadsteatern or stadsteaternvasteras.se

**suggestedRules:**
- For 404 errors: municipal sites often nest pages under /kultur or /noje subpaths

---

### Source: gr-na-lund-n-je

| Field | Value |
|-------|-------|
| likelyCategory | Cross-domain redirect to different domain |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.90 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - cross-domain redirect blocked. URL points to gronalund.se which redirects to www.gronalund.com. The .se domain appears to redirect to the .com domain. No HTML content available from original URL.

**discoveredPaths:**
(none)

**improvementSignals:**
- URL redirects to www.gronalund.com - different domain entirely
- gronalund.se may have been retired in favor of gronalund.com

**suggestedRules:**
- For cross-domain redirects: target domain may be the canonical source

---

### Source: malm-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failed - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - fetchHtml failed at network layer with ENOTFOUND. No HTML content available to analyze. Domain malmo-konserthus.se does not resolve via DNS.

**discoveredPaths:**
(none)

**improvementSignals:**
- Verify domain spelling: malmo-konserthus.se may be incorrect
- Try malmo.se/konserthus or konserthusmalmo.se

**suggestedRules:**
- For Swedish concert halls: check malmo.se subpaths or konserthus[city].se patterns

---

### Source: vasteras-art

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failed - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Cannot attempt discovery - fetchHtml failed at network layer with ENOTFOUND. No HTML content available to analyze. Domain vasterasart.se does not resolve via DNS.

**discoveredPaths:**
(none)

**improvementSignals:**
- Verify domain spelling: vasterasart.se may be incorrect
- Try vasteras.se/konst or vasteraskonst.se

**suggestedRules:**
- For Swedish art museums: check municipal site subpaths or [city]konst.se patterns

---
