## Rule Effectiveness Report batch-67

**Generated:** 2026-04-15T19:47:39.450Z
**Total rules generated:** 3
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| orebro-lan | 2 | ENTRY_PAGE_NO_EVENTS | /events, /program... | No | N/A |
| partille-arena | 2 | NEEDS_SUBPAGE_DISCOVERY | /event/23-maj-asme/ | No | N/A |
| malmo-konsthall | 2 | ENTRY_PAGE_NO_EVENTS | / | No | N/A |