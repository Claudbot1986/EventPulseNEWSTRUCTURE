## C4-AI Analysis Round 1 (batch-67)

**Timestamp:** 2026-04-15T19:44:29.600Z
**Sources analyzed:** 8

### Overall Pattern
Top failure categories: 3× DNS failure - domain does not exist, 1× Swedish municipal site with event paths in nav, 1× Event page found but extraction failed

---

### Source: orebro-lan

| Field | Value |
|-------|-------|
| likelyCategory | Swedish municipal site with event paths in nav |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.92 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /events, /program, /evenemang, /kalender, /schema, /kalendarium |

**humanLikeDiscoveryReasoning:**
Örebro municipality site has rich navigation with multiple Swedish event paths. The c0LinksFound shows 6 high-scoring paths (scores 10-5) all indicating event content. Swedish municipal sites consistently use /events, /program, /evenemang, or /kalender for event listings. C2 score of 11 suggests some event signals present but below threshold. Retry with highest-scoring path /events or /program.

**candidateRuleForC0C3:**
- pathPattern: `/events|/program|/evenemang|/kalender|/schema|/kalendarium`
- appliesTo: Swedish municipal and cultural sites (orebro.se, .kommun.se, .stad.se patterns)
- confidence: 0.85

**discoveredPaths:**
- /events [nav-link] anchor="derived-rule" conf=0.92
- /program [nav-link] anchor="derived-rule" conf=0.88
- /evenemang [nav-link] anchor="derived-rule" conf=0.85
- /kalender [nav-link] anchor="derived-rule" conf=0.82

**improvementSignals:**
- c0LinksFound contains 6 high-scoring event paths (/events, /program, /evenemang, /kalender, /schema, /kalendarium)
- c2Score=11 is close to threshold 12, suggests partial event signal
- Swedish municipal sites typically have /events or /kalender event listings

**suggestedRules:**
- For Swedish municipal sites (orebro.se, .kommun.se patterns), always attempt /events, /kalender, /program paths before declaring failure
- C0 derived rules should prioritize Swedish event keywords: evenemang, kalender, program, schema

---

### Source: helsingborgs-if

| Field | Value |
|-------|-------|
| likelyCategory | DNS failure - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
DNS resolution failed completely - the domain helsingborgsif.se does not exist. No paths can be discovered without resolving the domain. This is a terminal infrastructure failure requiring manual investigation.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed: getaddrinfo ENOTFOUND helsingborgsif.se
- Domain may have expired or been removed
- Consider checking for alternate domain (helsingborgsif.se vs helsingborg.se)

**suggestedRules:**
- DNS ENOTFOUND failures should be flagged for manual domain verification
- Check if site moved to parent domain or alternate TLD

---

### Source: hovet-1

| Field | Value |
|-------|-------|
| likelyCategory | DNS failure - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
DNS resolution failed completely - the domain thehovet.se does not exist. No paths can be discovered without resolving the domain. This is a terminal infrastructure failure requiring manual investigation.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed: getaddrinfo ENOTFOUND thehovet.se
- Domain may have expired or been removed
- Verify if venue operates under different domain

**suggestedRules:**
- DNS ENOTFOUND failures require manual domain verification
- Check venue's official website through parent organization

---

### Source: partille-arena

| Field | Value |
|-------|-------|
| likelyCategory | Event page found but extraction failed |
| failCategory | EXTRACTION_PATTERN_MISMATCH |
| failCategoryConfidence | 0.78 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /event/23-maj-asme/ |

**humanLikeDiscoveryReasoning:**
Partille Arena site discovered 8 event candidates with a winner URL at /event/23-maj-asme/. The extraction failed at C1 (no-main verdict) but date count of 1 confirms event data exists. The site uses a /event/[slug] URL structure typical for venues. Retry with direct event page extraction or venue-specific patterns.

**candidateRuleForC0C3:**
- pathPattern: `/event/*|/events/*|/konsert/*`
- appliesTo: Swedish arena and venue sites (partillearena.se, .arena.se patterns)
- confidence: 0.72

**discoveredPaths:**
- /event/23-maj-asme/ [url-pattern] anchor="discovered-candidate" conf=0.80

**improvementSignals:**
- c0Candidates=8 indicates some event content was discovered
- c0WinnerUrl points to valid event page: /event/23-maj-asme/
- c1DateCount=1 confirms date information exists
- c2Score=6 suggests weak but present event structure

**suggestedRules:**
- Partille Arena uses /event/[slug] URL pattern for individual events
- Extraction patterns may not match arena-specific event markup
- Consider venue-specific extraction rules for arena/concert sites

---

### Source: lunds-stadsteatern

| Field | Value |
|-------|-------|
| likelyCategory | HTTP 404 - page does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
HTTP 404 response indicates the page at /stadsteatern does not exist on lund.se. The Lund City Theatre may have been restructured or moved. This requires manual investigation to find the correct URL.

**discoveredPaths:**
(none)

**improvementSignals:**
- HTTP 404 response - the URL /stadsteatern does not exist
- Lund stadsteater may have moved to different URL structure
- Check if Lund Theatre is under lund.se/sv/kultur-or-similar

**suggestedRules:**
- HTTP 404 failures should be flagged for manual URL verification
- Swedish theatre sites may use /teater, /scen, or /kultur paths

---

### Source: malmo-hockey

| Field | Value |
|-------|-------|
| likelyCategory | DNS failure - domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
DNS resolution failed for malmöhockey.se (xn--malmhockey-hcb.se). The domain does not exist or has expired. This is a terminal infrastructure failure requiring manual investigation.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed: getaddrinfo ENOTFOUND xn--malmhockey-hcb.se (Punycode for malmöhockey.se)
- Domain may have expired or team may no longer exist
- Consider checking malmoredhawks.com or similar hockey team sites

**suggestedRules:**
- DNS ENOTFOUND failures with Swedish special characters require Punycode verification
- Hockey team sites may have been rebranded or merged

---

### Source: malmo-konsthall

| Field | Value |
|-------|-------|
| likelyCategory | Cross-domain redirect blocked |
| failCategory | NEEDS_SUBPAGE_DISCOVERY |
| failCategoryConfidence | 0.85 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | https://malmokonsthall.se/ |

**humanLikeDiscoveryReasoning:**
konsthall.malmo.se redirects to malmokonsthall.se but the redirect was blocked. The target domain malmokonsthall.se is the actual content source. Retry discovery on the target domain with standard event paths (/events, /utställningar, /exhibitions).

**candidateRuleForC0C3:**
- pathPattern: `/events|/utställningar|/exhibitions|/exhibitions|/calendar`
- appliesTo: Swedish art museum and gallery sites (malmo.se, .konsthall.se patterns)
- confidence: 0.78

**discoveredPaths:**
- https://malmokonsthall.se/ [derived] anchor="redirected-domain" conf=0.90

**improvementSignals:**
- Cross-domain redirect blocked: konsthall.malmo.se → malmokonsthall.se
- Target domain malmokonsthall.se is the actual event source
- Should attempt discovery on malmokonsthall.se directly

**suggestedRules:**
- When cross-domain redirect is blocked, add target domain to source list
- Swedish museum sites may use subdomain redirects to main domain

---

### Source: uppsala-museum

| Field | Value |
|-------|-------|
| likelyCategory | Server timeout - unresponsive |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.90 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Server timeout after 20000ms indicates the server at uppsalamuseum.se is unresponsive. This could be temporary overload or server issues. Requires manual verification and potential retry during different time period.

**discoveredPaths:**
(none)

**improvementSignals:**
- Timeout of 20000ms exceeded - server unresponsive
- Server may be overloaded, down, or blocking requests
- Consider retrying during off-peak hours

**suggestedRules:**
- Timeout failures should be flagged for manual retry or verification
- Swedish museum sites may have high traffic periods

---
