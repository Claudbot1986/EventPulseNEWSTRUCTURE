## Rule Effectiveness Report batch-83

**Generated:** 2026-04-16T16:26:45.309Z
**Total rules generated:** 1
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| chalmers | 2 | no_viable_path_found | /utbildning/hitta-program/, / | No | N/A |