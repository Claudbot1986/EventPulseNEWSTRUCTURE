## Rule Effectiveness Report batch-76

**Generated:** 2026-04-15T20:22:31.718Z
**Total rules generated:** 0
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|