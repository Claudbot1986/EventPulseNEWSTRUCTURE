## Rule Effectiveness Report batch-74

**Generated:** 2026-04-15T20:13:27.391Z
**Total rules generated:** 2
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| vega | 1 | NEEDS_SUBPAGE_DISCOVERY | https://tobiasnygren.se/ | No | N/A |
| scandinavium | 1 | NEEDS_SUBPAGE_DISCOVERY | https://gotevent.se/scandinavium | No | N/A |