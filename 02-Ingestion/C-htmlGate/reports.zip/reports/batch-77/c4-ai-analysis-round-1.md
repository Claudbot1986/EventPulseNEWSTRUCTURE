## C4-AI Analysis Round 1 (batch-77)

**Timestamp:** 2026-04-15T20:22:58.498Z
**Sources analyzed:** 2

### Overall Pattern
Top failure categories: 2× unclear

---

### Source: umea-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: goteborgs-litteraturhus

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---
