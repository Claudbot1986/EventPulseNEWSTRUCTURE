## Rule Effectiveness Report batch-70

**Generated:** 2026-04-15T19:58:18.648Z
**Total rules generated:** 2
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| lulea-konserthus | 1 | NEEDS_SUBPAGE_DISCOVERY | https://lulea.se, https://lulea.se/kalender... | No | N/A |
| jarfalla | 3 | ENTRY_PAGE_NO_EVENTS | /foretagochnaringsliv/foretagsnatverkochevenemang.4.7174b53f19482f39e501d8ed.html | No | N/A |