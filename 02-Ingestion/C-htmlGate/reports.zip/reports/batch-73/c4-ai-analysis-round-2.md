## C4-AI Analysis Round 2 (batch-73)

**Timestamp:** 2026-04-15T20:06:23.758Z
**Sources analyzed:** 9

### Overall Pattern
Top failure categories: 9× unclear

---

### Source: lulea-stadsteatern

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: kungliga-operan

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: jazz-i-lund

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: uppsala-konserthus-1

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: paddan

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: visit-stockholm

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: linkoping-city

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: linnaeus-museum

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---

### Source: lunds-museum

| Field | Value |
|-------|-------|
| likelyCategory | unclear |
| failCategory | UNKNOWN |
| failCategoryConfidence | 0.50 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**discoveredPaths:**
(none)

**improvementSignals:**
- AI analysis unavailable

**suggestedRules:**

---
