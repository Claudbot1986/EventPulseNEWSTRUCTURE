## Rule Effectiveness Report batch-73

**Generated:** 2026-04-15T20:08:24.777Z
**Total rules generated:** 2
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| kungliga-operan | 1 | EXTRACTION_PATTERN_MISMATCH | /forestallningar/familjekonsert-med-hovkapellet | No | N/A |
| visit-stockholm | 1 | ENTRY_PAGE_NO_EVENTS | /events, /program... | No | N/A |