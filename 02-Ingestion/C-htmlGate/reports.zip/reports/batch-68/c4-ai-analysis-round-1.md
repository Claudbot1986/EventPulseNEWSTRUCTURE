## C4-AI Analysis Round 1 (batch-68)

**Timestamp:** 2026-04-15T19:48:27.787Z
**Sources analyzed:** 6

### Overall Pattern
Top failure categories: 2× Domain does not exist, 1× Homepage lacks events, event paths exist, 1× Redirect loop blocks event access

---

### Source: kb18

| Field | Value |
|-------|-------|
| likelyCategory | Homepage lacks events, event paths exist |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.92 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /events, /program, /kalender, /schema, /evenemang, /kalendarium |

**humanLikeDiscoveryReasoning:**
C0 derived rules found 6 high-confidence event paths on kb18.se. The homepage lacks direct event content but Swedish cultural sites typically expose events via /events, /program, or /kalender. These paths have strong derived-rule scores (10 down to 5), indicating reliable event-listing patterns. Retry-pool should attempt these paths before manual review.

**candidateRuleForC0C3:**
- pathPattern: `/events|/program|/kalender|/schema|/evenemang|/kalendarium`
- appliesTo: Swedish municipal and cultural venues (kb18.se pattern) where homepage lacks events but nav contains standard Swedish event paths
- confidence: 0.87

**discoveredPaths:**
- /events [nav-link] anchor="derived-rule" conf=0.92
- /program [nav-link] anchor="derived-rule" conf=0.88
- /kalender [nav-link] anchor="derived-rule" conf=0.85
- /schema [nav-link] anchor="derived-rule" conf=0.80
- /evenemang [nav-link] anchor="derived-rule" conf=0.78
- /kalendarium [nav-link] anchor="derived-rule" conf=0.72

**improvementSignals:**
- c0LinksFound contains 6 high-scoring event paths (/events, /program, /kalender, /schema, /evenemang, /kalendarium)
- c0Candidates=0 but derived rules found paths - entry page is event-free but nav contains event links
- Swedish cultural site pattern: homepage → /events or /kalender typically yields event listings

**suggestedRules:**
- For Swedish municipal/cultural sites (kb18.se pattern), try /events, /program, /kalender paths derived from nav rules before marking as failure
- C0 derived rules successfully identified event paths - retry with these paths in retry-pool

---

### Source: liljevalchs-konsthall

| Field | Value |
|-------|-------|
| likelyCategory | Redirect loop blocks event access |
| failCategory | LIKELY_JS_RENDER |
| failCategoryConfidence | 0.78 |
| nextQueue | D |
| discoveryAttempted | true |
| discoveryPathsTried | /kalender/when-we-see-us/ |
| directRouting | D (conf=0.88) |

**humanLikeDiscoveryReasoning:**
liljevalchs.se found a specific event URL (/kalender/when-we-see-us/) but encountered redirect loop during fetch. Redirect loops are characteristic of client-side routing frameworks (React Router, Vue Router, Next.js). Route to D for browser-based rendering that can handle JS redirects.

**candidateRuleForC0C3:**
- pathPattern: `/kalender/*`
- appliesTo: liljevalchs.se and similar Swedish art galleries using client-side routing with redirect loops
- confidence: 0.75

**discoveredPaths:**
- /kalender/when-we-see-us/ [nav-link] anchor="derived-rule" conf=0.75

**improvementSignals:**
- c0WinnerUrl found: /kalender/when-we-see-us/ but fetchHtml failed with redirect loop
- Redirect loops often indicate client-side routing/JS handling
- c1Verdict=unfetchable suggests site uses JS-based navigation

**suggestedRules:**
- Redirect loop on specific event URL indicates JS-rendered routing - route to D for browser rendering
- liljevalchs.se uses client-side routing that causes redirect loops with simple HTTP clients

---

### Source: stockholm-jazz-festival

| Field | Value |
|-------|-------|
| likelyCategory | Domain does not exist |
| failCategory | LOW_VALUE_SOURCE |
| failCategoryConfidence | 0.98 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failure (ENOTFOUND) means the domain stojazz.se does not exist or is not reachable. No paths can be discovered when the domain itself is non-functional. This is a terminal failure requiring manual domain verification.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS resolution failed: getaddrinfo ENOTFOUND stojazz.se
- Domain appears to be inactive or never registered
- No network path exists to reach this source

**suggestedRules:**
- ENOTFOUND errors indicate domain is non-existent - flag for manual domain verification
- stojazz.se may be misspelling of stockholmjazz.se or similar - manual review needed

---

### Source: malmo-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | Domain encoding issue or inactive |
| failCategory | LOW_VALUE_SOURCE |
| failCategoryConfidence | 0.98 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failure on punycode domain (xn--malmkonserthus-ypb.se) indicates the Swedish concert hall website is either inactive, the URL is incorrect, or DNS is misconfigured. Manual review needed to verify correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS resolution failed: getaddrinfo ENOTFOUND xn--malmkonserthus-ypb.se
- Punycode domain failed to resolve - site may be inactive or URL incorrect
- Swedish characters in domain may need proper encoding

**suggestedRules:**
- ENOTFOUND on punycode domain indicates site is inactive or URL needs correction
- malmökonserthus.se may need verification - try malmokonserthus.se or konserthus.se variants

---

### Source: repo-festival

| Field | Value |
|-------|-------|
| likelyCategory | Domain does not exist |
| failCategory | LOW_VALUE_SOURCE |
| failCategoryConfidence | 0.98 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
DNS resolution failure (ENOTFOUND) means the domain repo.se does not exist or is not reachable. No paths can be discovered when the domain itself is non-functional. This is a terminal failure requiring manual domain verification.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS resolution failed: getaddrinfo ENOTFOUND repo.se
- Domain repo.se appears to be inactive or unregistered
- No network path exists to reach this source

**suggestedRules:**
- ENOTFOUND errors indicate domain is non-existent - flag for manual domain verification
- repo.se may be inactive festival site - manual review needed

---

### Source: stangebrofestivalen

| Field | Value |
|-------|-------|
| likelyCategory | Server timeout - site unreachable |
| failCategory | LOW_VALUE_SOURCE |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |

**humanLikeDiscoveryReasoning:**
Connection timeout (20000ms exceeded) indicates the server at stangebro.se is either temporarily unavailable, experiencing heavy load, or blocking requests. This is a terminal network failure requiring manual verification of site availability.

**discoveredPaths:**
(none)

**improvementSignals:**
- Connection timeout: timeout of 20000ms exceeded
- Server is unreachable or responding too slowly
- May be temporary unavailability or network issue

**suggestedRules:**
- Timeout errors indicate server unavailability - flag for manual retry or domain verification
- stangebro.se may be temporarily down or have network issues - manual review needed

---
