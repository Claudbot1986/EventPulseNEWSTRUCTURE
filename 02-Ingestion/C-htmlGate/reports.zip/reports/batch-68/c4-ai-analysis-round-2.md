## C4-AI Analysis Round 2 (batch-68)

**Timestamp:** 2026-04-15T19:49:40.935Z
**Sources analyzed:** 10

### Overall Pattern
Top failure categories: 3× Domain does not exist, 1× Swedish cultural site with event paths found, 1× IDN domain encoding issue

---

### Source: kb18

| Field | Value |
|-------|-------|
| likelyCategory | Swedish cultural site with event paths found |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.92 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /events, /program, /kalender, /schema, /evenemang, /kalendarium |

**humanLikeDiscoveryReasoning:**
kb18.se is a Swedish cultural/municipal site. C0 found 30+ event-indicating links with high confidence scores. Top paths: /events (score=10), /program (score=9), /kalender (score=8). These are standard Swedish event listing paths. Retry with highest-scoring path /events first.

**candidateRuleForC0C3:**
- pathPattern: `/events|/program|/kalender|/schema|/evenemang|/kalendarium`
- appliesTo: Swedish cultural venues, municipal sites, and event calendars
- confidence: 0.88

**discoveredPaths:**
- /events [nav-link] anchor="derived-rule" conf=0.85
- /program [nav-link] anchor="derived-rule" conf=0.80
- /kalender [nav-link] anchor="derived-rule" conf=0.75
- /schema [nav-link] anchor="derived-rule" conf=0.70
- /evenemang [nav-link] anchor="derived-rule" conf=0.65

**improvementSignals:**
- Multiple high-scoring event paths discovered in c0LinksFound
- C2 score=4 indicates page has event-heading markers
- Swedish site with common /events, /program, /kalender patterns

**suggestedRules:**
- Try Swedish cultural/municipal event paths: /events, /program, /kalender, /schema, /evenemang, /kalendarium
- Use anchor text scoring: evenemang=10, kalender=8, program=9, schema=7

---

### Source: stockholm-jazz-festival

| Field | Value |
|-------|-------|
| likelyCategory | Domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network failure - domain stojazz.se cannot be resolved. No paths attempted. Manual review needed to verify correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed: getaddrinfo ENOTFOUND stojazz.se
- Domain may have expired or been mistyped

**suggestedRules:**
- Verify domain spelling - stojazz.se may not exist
- Try common alternatives: stockholmjazz.se, stockholm-jazz.se, sjf.se

---

### Source: malmo-konserthus

| Field | Value |
|-------|-------|
| likelyCategory | IDN domain encoding issue |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network failure for IDN domain. The punycode encoding xn--malmkonserthus-ypb.se failed. Manual review needed to determine correct ASCII domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed for IDN domain xn--malmkonserthus-ypb.se
- Unicode encoding may be incorrect - should try malmokonserthus.se or malmo-konserthus.se

**suggestedRules:**
- Try ASCII equivalent: malmokonserthus.se or malmo-konserthus.se
- Verify IDN encoding of Swedish characters (ö → o)

---

### Source: repo-festival

| Field | Value |
|-------|-------|
| likelyCategory | Domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network failure - domain repo.se cannot be resolved. No paths attempted. Manual review needed to verify correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed: getaddrinfo ENOTFOUND repo.se
- Domain may be inactive or mistyped

**suggestedRules:**
- Verify domain exists - repo.se returned ENOTFOUND
- Try alternatives: repo-festival.se, repofestival.se

---

### Source: stangebrofestivalen

| Field | Value |
|-------|-------|
| likelyCategory | Network timeout |
| failCategory | insufficient_html_signal |
| failCategoryConfidence | 0.70 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network timeout - server at stangebro.se did not respond within 20s. This is a transient network issue, not a discovery failure. Retry may succeed.

**discoveredPaths:**
(none)

**improvementSignals:**
- Request timed out after 20000ms
- Server may be slow or temporarily unavailable

**suggestedRules:**
- Retry with extended timeout or reduced concurrency
- Try alternative network path or proxy

---

### Source: goteborgs-film-festival

| Field | Value |
|-------|-------|
| likelyCategory | Domain does not exist |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Network failure - domain gothenburgfilmfestival.com cannot be resolved. No paths attempted. Manual review needed to verify correct domain.

**discoveredPaths:**
(none)

**improvementSignals:**
- DNS lookup failed: getaddrinfo ENOTFOUND gothenburgfilmfestival.com
- Domain may have Swedish equivalent

**suggestedRules:**
- Try Swedish domain: goteborgsfilmfestival.se or gothenburgfilmfestival.se
- Verify correct domain for Göteborg Film Festival

---

### Source: goteborgsoperan

| Field | Value |
|-------|-------|
| likelyCategory | Redirect loop to www prefix |
| failCategory | insufficient_html_signal |
| failCategoryConfidence | 0.75 |
| nextQueue | retry-pool |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Redirect loop detected - opera.se/goteborg redirects to www.opera.se/goteborg which loops back. Retry with www prefix should resolve.

**discoveredPaths:**
(none)

**improvementSignals:**
- Redirect loop detected to https://www.opera.se/goteborg
- Should retry with www prefix included in URL

**suggestedRules:**
- Retry with www.opera.se/goteborg directly
- Handle redirect loops by following to final destination

---

### Source: grand

| Field | Value |
|-------|-------|
| likelyCategory | Extraction pattern mismatch |
| failCategory | EXTRACTION_PATTERN_MISMATCH |
| failCategoryConfidence | 0.85 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /event-calendar |

**humanLikeDiscoveryReasoning:**
grandmalmo.se/event-calendar was identified as C0 winner with high C2 score (32). However extraction returned 0 events despite promising signals. This indicates extraction pattern mismatch - the page has event-like content but our patterns don't match. Retry with different extraction approach or manual review.

**candidateRuleForC0C3:**
- pathPattern: `/event-calendar|/calendar|/events|/program`
- appliesTo: Venue sites with calendar-style event listings
- confidence: 0.65

**discoveredPaths:**
- /event-calendar [url-pattern] anchor="event-calendar" conf=0.70

**improvementSignals:**
- C2 score=32 was promising but extraction returned 0 events
- Page at /event-calendar has venue-marker class but no extractable events
- C1 verdict=noise suggests page content is not event-structured

**suggestedRules:**
- Investigate /event-calendar page structure for custom event markup
- Try alternative extraction patterns for venue-marker class
- Check if events require JS rendering or have non-standard HTML

---

### Source: grona-lund

| Field | Value |
|-------|-------|
| likelyCategory | Low signal page with event candidates |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.70 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /biljetter |

**humanLikeDiscoveryReasoning:**
gronalund.com has low C2 score (8) but 10 C0 candidates were found. The /biljetter path is a Swedish ticket/event path that may contain event listings. Retry with this path.

**candidateRuleForC0C3:**
- pathPattern: `/biljetter|/tickets|/events|/program`
- appliesTo: Swedish entertainment venues and amusement parks
- confidence: 0.60

**discoveredPaths:**
- /biljetter [url-pattern] anchor="biljetter" conf=0.60

**improvementSignals:**
- C2 score=8 is below threshold (12) but page has event-heading markers
- 10 C0 candidates found but no winner URL
- /biljetter path may contain ticket/event information

**suggestedRules:**
- Try /biljetter path for ticket listings
- Try /events or /program for event calendar
- Lower C2 threshold for known venue sites

---

### Source: h-gskolan-i-sk-vde

| Field | Value |
|-------|-------|
| likelyCategory | 404 error on event path |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.75 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /evenemang |

**humanLikeDiscoveryReasoning:**
his.se/evenemang returned 404. The /evenemang path doesn't exist on this university site. Retry with root URL his.se to discover correct event path, or try alternatives like /kalender, /aktuellt, /events.

**candidateRuleForC0C3:**
- pathPattern: `/kalender|/aktuellt|/events|/program`
- appliesTo: Swedish university and higher education sites
- confidence: 0.70

**discoveredPaths:**
(none)

**improvementSignals:**
- HTTP 404 on /evenemang path
- Root URL his.se may have events at different path
- University sites often use /aktuellt, /kalender, or /events

**suggestedRules:**
- Try his.se/ for root homepage discovery
- Try his.se/kalender, his.se/aktuellt, his.se/events
- University sites may use different event naming conventions

---
