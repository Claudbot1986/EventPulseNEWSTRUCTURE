## Rule Effectiveness Report batch-68

**Generated:** 2026-04-15T19:51:22.186Z
**Total rules generated:** 4
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| kb18 | 2 | ENTRY_PAGE_NO_EVENTS | /events, /program... | No | N/A |
| liljevalchs-konsthall | 1 | LIKELY_JS_RENDER | /kalender/when-we-see-us/ | No | N/A |
| grand | 3 | EXTRACTION_PATTERN_MISMATCH | /event-calendar | No | N/A |
| grona-lund | 3 | NEEDS_SUBPAGE_DISCOVERY | /biljetter | No | N/A |