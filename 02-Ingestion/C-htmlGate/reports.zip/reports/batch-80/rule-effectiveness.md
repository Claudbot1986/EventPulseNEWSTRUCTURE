## Rule Effectiveness Report batch-80

**Generated:** 2026-04-16T16:14:25.848Z
**Total rules generated:** 0
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|