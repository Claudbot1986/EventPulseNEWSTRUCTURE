## C4-AI Analysis Round 3 (batch-80)

**Timestamp:** 2026-04-16T16:14:03.878Z
**Sources analyzed:** 1

### Overall Pattern
Top failure categories: 1× SSL certificate mismatch blocks all access

---

### Source: botaniska-tradgarden

| Field | Value |
|-------|-------|
| likelyCategory | SSL certificate mismatch blocks all access |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | false |

**humanLikeDiscoveryReasoning:**
Could not attempt human-like discovery: c0LinksFound=[] and C2 fetchHtml failed with SSL certificate mismatch. The page content was never retrieved, so no navigation analysis is possible. Certificate error 'Host: botaniska.se. is not in the cert's altnames: DNS:*.vgregion.se, DNS:vgregion.se' indicates server misconfiguration. Without HTML content, no event-indicating paths can be discovered from c0LinksFound.

**discoveredPaths:**
(none)

**improvementSignals:**
- SSL certificate mismatch: botaniska.se not in *.vgregion.se cert altnames
- Empty c0LinksFound indicates page content was never retrieved due to fetch failure
- Cannot attempt human-like discovery without HTML content

**suggestedRules:**
- For SSL cert failures with municipal Swedish domains (*.vgregion.se), consider if site moved to different infrastructure
- botaniska.se appears to be hosted on VGR infrastructure but cert wasn't provisioned correctly
- Try HTTP (non-HTTPS) fallback for this source to bypass cert validation

---
