## C4-AI Analysis Round 1 (batch-78)

**Timestamp:** 2026-04-16T04:39:30.532Z
**Sources analyzed:** 5

### Overall Pattern
Top failure categories: 2× DNS resolution failure - site unreachable, 1× Entry page lacks events, subpage exists, 1× Redirect loop indicates JS-rendered content

---

### Source: af

| Field | Value |
|-------|-------|
| likelyCategory | Entry page lacks events, subpage exists |
| failCategory | ENTRY_PAGE_NO_EVENTS |
| failCategoryConfidence | 0.75 |
| nextQueue | retry-pool |
| discoveryAttempted | true |
| discoveryPathsTried | /sv-scenverksamhet, /evenemang, /kalender |

**humanLikeDiscoveryReasoning:**
Entry page (af.lu.se) scored 4 with unclear verdict. c0WinnerUrl=https://af.lu.se/sv-scenverksamhet suggests events exist at /sv-scenverksamhet path. Swedish university arts faculties typically have dedicated performance/event sections. Retry with this path.

**candidateRuleForC0C3:**
- pathPattern: `/sv-scenverksamhet|/evenemang|/kalender|/program`
- appliesTo: Swedish university arts/cultural sites with event listings
- confidence: 0.72

**discoveredPaths:**
- /sv-scenverksamhet [derived] anchor="Scenverksamhet (Stage Events)" conf=0.78

**improvementSignals:**
- c0WinnerUrl points to /sv-scenverksamhet which is a Swedish event page
- c0Candidates=3 but c0LinksFound empty - links may not have been captured
- C2 score 4 suggests some event-like content but below threshold

**suggestedRules:**
- If entry page score < 6 but c0WinnerUrl exists, retry with winner URL path
- Swedish cultural sites often use /sv-scenverksamhet or /evenemang for events

---

### Source: arkdes

| Field | Value |
|-------|-------|
| likelyCategory | Redirect loop indicates JS-rendered content |
| failCategory | LIKELY_JS_RENDER |
| failCategoryConfidence | 0.82 |
| nextQueue | D |
| discoveryAttempted | true |
| discoveryPathsTried | /kalender/ |
| directRouting | D (conf=0.88) |

**humanLikeDiscoveryReasoning:**
Redirect loop detected at https://arkdes.se/kalender - this is a classic sign of client-side routing where the server doesn't have the /kalender route but the JS framework handles it. Route to D-stage for rendering.

**candidateRuleForC0C3:**
- pathPattern: `/kalender|/events|/program`
- appliesTo: Swedish museum and cultural sites with JS-rendered event calendars
- confidence: 0.78

**discoveredPaths:**
- /kalender/ [derived] anchor="Kalender (Calendar)" conf=0.85

**improvementSignals:**
- Redirect loop at /kalender/ strongly suggests client-side routing
- c0Candidates=6 but c0LinksFound empty - links may be dynamically generated
- Swedish museum sites often use JS frameworks for event calendars

**suggestedRules:**
- If redirect loop detected on known event path, route to D-stage rendering
- Museum and cultural sites frequently use React/Vue for event listings

---

### Source: arbetsam

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure - site unreachable |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |
| discoveryPathsTried | / |

**humanLikeDiscoveryReasoning:**
DNS resolution failed with ENOTFOUND for arbetam.se. This is a terminal failure - the site is completely unreachable. No event discovery possible without network access. Route to manual-review for human verification.

**candidateRuleForC0C3:**
- pathPattern: ``
- appliesTo: 
- confidence: 0.50

**discoveredPaths:**
(none)

**improvementSignals:**
- getaddrinfo ENOTFOUND - DNS cannot resolve arbetam.se
- No event candidates found due to complete fetch failure
- Site may be down, misconfigured, or blocked

**suggestedRules:**
- DNS ENOTFOUND errors should route to manual-review for human verification
- Site may have been taken down or DNS not properly configured

---

### Source: b-republic

| Field | Value |
|-------|-------|
| likelyCategory | DNS resolution failure - site unreachable |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |
| discoveryPathsTried | / |

**humanLikeDiscoveryReasoning:**
DNS resolution failed with ENOTFOUND for brepublic.se. This is a terminal failure - the site is completely unreachable. No event discovery possible without network access. Route to manual-review for human verification.

**candidateRuleForC0C3:**
- pathPattern: ``
- appliesTo: 
- confidence: 0.50

**discoveredPaths:**
(none)

**improvementSignals:**
- getaddrinfo ENOTFOUND - DNS cannot resolve brepublic.se
- No event candidates found due to complete fetch failure
- Site may be down, misconfigured, or blocked

**suggestedRules:**
- DNS ENOTFOUND errors should route to manual-review for human verification
- Site may have been taken down or DNS not properly configured

---

### Source: arkitekturgalleriet

| Field | Value |
|-------|-------|
| likelyCategory | SSL certificate mismatch - site unreachable |
| failCategory | no_viable_path_found |
| failCategoryConfidence | 0.95 |
| nextQueue | manual-review |
| discoveryAttempted | true |
| discoveryPathsTried | / |

**humanLikeDiscoveryReasoning:**
SSL certificate mismatch for arkitekturgalleriet.se - hostname not in cert altnames. This is a terminal failure - the site is unreachable due to SSL configuration issues. No event discovery possible. Route to manual-review for human verification.

**candidateRuleForC0C3:**
- pathPattern: ``
- appliesTo: 
- confidence: 0.50

**discoveredPaths:**
(none)

**improvementSignals:**
- SSL certificate mismatch - hostname not in cert altnames
- No event candidates found due to complete fetch failure
- Site may have expired certificate or misconfigured SSL

**suggestedRules:**
- SSL certificate mismatch errors should route to manual-review for human verification
- Site may have expired SSL certificate or misconfigured server

---
