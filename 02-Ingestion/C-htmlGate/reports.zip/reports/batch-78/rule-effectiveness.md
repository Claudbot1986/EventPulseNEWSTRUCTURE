## Rule Effectiveness Report batch-78

**Generated:** 2026-04-16T04:41:06.843Z
**Total rules generated:** 2
**Rules applied in next round:** 0
**Rules that improved outcomes:** 0

| Source | Gen Round | Category | Suggested Paths | Applied? | Helped? |
|--------|----------|---------|-----------------|----------|---------|
| af | 2 | ENTRY_PAGE_NO_EVENTS | /sv-scenverksamhet, /evenemang... | No | N/A |
| arkdes | 1 | LIKELY_JS_RENDER | /kalender/ | No | N/A |