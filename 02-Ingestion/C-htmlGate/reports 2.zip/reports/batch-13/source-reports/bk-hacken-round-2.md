## Source Report: bk-hacken

| Field | Value |
|-------|-------|
| batchId | batch-13 |
| roundNumber | 2 |
| sourceId | bk-hacken |
| url | https://hacken.se/ |
| winningStage | C3 |
| outcomeType | fail |
| routeSuggestion | Fail |
| failType | discovery_failure |
| evidence | C0: no internal event candidates discovered |
| eventsFound | 0 |
| c0Candidates | 0 |
| winnerUrl | null |
| c2Verdict | unclear |
| c2Score | 0 |
| error | none |