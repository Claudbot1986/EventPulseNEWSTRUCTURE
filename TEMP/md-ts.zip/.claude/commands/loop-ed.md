# /loop-ed

Läs först:
- README.md
- goals.md
- current-task.md
- handoff.md
- relevant loop.md eller workflow-fil

Gör sedan:

## Generalization Gate (MANDATORY)

**"Do not generalize from one site."**

En enda sajt kan motivera en observation, aldrig en regel.

**Regler:**

1. **"One domain is evidence of a symptom, not proof of a rule."**
   - Om endast en domän uppvisar problemet: klassificera som Site-Specific
   - Om 2–3+ domäner uppvisar samma problem: proceed with General

2. **"No global heuristic may be changed based on a single domain."**
   - IGNORE_PATTERNS = aldrig ändra för en enskild sajt
   - scoring-vikter = aldrig ändra för en enskild sajt
   - candidate ranking = aldrig ändra för en enskild sajt
   - URL token logic = aldrig ändra för en enskild sajt
   - negative keyword lists = aldrig ändra för en enskild sajt

3. **"If only one domain exhibits the issue, stop and classify it as Site-Specific."**
   - Tillåtna alternativ: source adapter, source-specific config, manual review
   - INTE: ändring i C0/C1/C2 för att fixa en enskild sajt

4. **Cross-Site Verification innan heuristik-ändring:**
   - Minimum 2–3 olika domäner måste visa samma mönster
   - Annars: "Provisionally General" → gör INTE implementation ännu

**Konsekvens:**
- Att ändra `IGNORE_PATTERNS` för Folkoperan = förbjudet utan multi-site bevis
- Att lägga till www-normalisering = tillåtet (canonicalization är generellt)

1. Identifiera största verifierbara gapet mot goals.md
2. Välj exakt ett problem
3. Gör minsta säkra förändring
4. Verifiera förändringen
5. Uppdatera handoff.md
6. Avgör om samma problem ska fortsätta eller om current-task.md ska ändras
7. Gör git commit

Svara alltid på svenska.
Inga broad refactors.
Ett problem åt gången.
Om handoff.md inte uppdaterades är uppgiften inte klar.
